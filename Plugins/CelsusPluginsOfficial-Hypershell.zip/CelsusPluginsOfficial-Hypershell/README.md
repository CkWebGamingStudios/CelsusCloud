# CelsusPluginsOfficial
A place for storing all celsus plugins by own celsus developer for users.
